---
name: Enhancement Request
about: File an enhancement request.
---

## Enhancement Request

_Provide a descriptive title and a detailed explanation of the problem the requested enhancement would solve. Ensure that your issue has not been filed before._
