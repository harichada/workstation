/**
 * @file tlib/injected/allfunc.h
 *
 * @copyright 2014-2018 Bill Zissimopoulos
 */

#ifndef TLIB_INJECTED_ALLFUNC_H_INCLUDED
#define TLIB_INJECTED_ALLFUNC_H_INCLUDED

#include <tlib/injected/curlfunc.h>
#include <tlib/injected/stdfunc.h>

#endif
