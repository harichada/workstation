This directory contains binaries for backwards compatibility testing.

- `v1.1/passthrough-fuse`: testing of changes related to `struct fuse_stat_ex` (`v1.2B3`)
- `v1.2/memfs`: testing of `FSP_FSCTL_VOLUME_PARAMS` size change (`v1.3B3`)
